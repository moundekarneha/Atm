﻿
namespace Atm
{
    partial class MainClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMseb = new System.Windows.Forms.Button();
            this.btnBsnl = new System.Windows.Forms.Button();
            this.btnMinistatement = new System.Windows.Forms.Button();
            this.btnLic = new System.Windows.Forms.Button();
            this.btnBalance = new System.Windows.Forms.Button();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.btnWithdraw = new System.Windows.Forms.Button();
            this.btnDeposite = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnMseb
            // 
            this.btnMseb.Location = new System.Drawing.Point(120, 137);
            this.btnMseb.Name = "btnMseb";
            this.btnMseb.Size = new System.Drawing.Size(75, 23);
            this.btnMseb.TabIndex = 0;
            this.btnMseb.Text = "Mseb";
            this.btnMseb.UseVisualStyleBackColor = true;
            this.btnMseb.Click += new System.EventHandler(this.btnMseb_Click);
            // 
            // btnBsnl
            // 
            this.btnBsnl.Location = new System.Drawing.Point(120, 166);
            this.btnBsnl.Name = "btnBsnl";
            this.btnBsnl.Size = new System.Drawing.Size(75, 23);
            this.btnBsnl.TabIndex = 1;
            this.btnBsnl.Text = "Bsnl";
            this.btnBsnl.UseVisualStyleBackColor = true;
            this.btnBsnl.Click += new System.EventHandler(this.btnBsnl_Click);
            // 
            // btnMinistatement
            // 
            this.btnMinistatement.Location = new System.Drawing.Point(120, 224);
            this.btnMinistatement.Name = "btnMinistatement";
            this.btnMinistatement.Size = new System.Drawing.Size(75, 23);
            this.btnMinistatement.TabIndex = 3;
            this.btnMinistatement.Text = "Ministatment";
            this.btnMinistatement.UseVisualStyleBackColor = true;
            this.btnMinistatement.Click += new System.EventHandler(this.btnMinistatement_Click);
            // 
            // btnLic
            // 
            this.btnLic.Location = new System.Drawing.Point(120, 195);
            this.btnLic.Name = "btnLic";
            this.btnLic.Size = new System.Drawing.Size(75, 23);
            this.btnLic.TabIndex = 2;
            this.btnLic.Text = "Lic";
            this.btnLic.UseVisualStyleBackColor = true;
            this.btnLic.Click += new System.EventHandler(this.btnLic_Click);
            // 
            // btnBalance
            // 
            this.btnBalance.Location = new System.Drawing.Point(564, 224);
            this.btnBalance.Name = "btnBalance";
            this.btnBalance.Size = new System.Drawing.Size(75, 23);
            this.btnBalance.TabIndex = 7;
            this.btnBalance.Text = "Balance";
            this.btnBalance.UseVisualStyleBackColor = true;
            this.btnBalance.Click += new System.EventHandler(this.btnBalance_Click);
            // 
            // btnTransfer
            // 
            this.btnTransfer.Location = new System.Drawing.Point(564, 195);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(75, 23);
            this.btnTransfer.TabIndex = 6;
            this.btnTransfer.Text = "Transfer";
            this.btnTransfer.UseVisualStyleBackColor = true;
            this.btnTransfer.Click += new System.EventHandler(this.btnTransfer_Click);
            // 
            // btnWithdraw
            // 
            this.btnWithdraw.Location = new System.Drawing.Point(564, 166);
            this.btnWithdraw.Name = "btnWithdraw";
            this.btnWithdraw.Size = new System.Drawing.Size(75, 23);
            this.btnWithdraw.TabIndex = 5;
            this.btnWithdraw.Text = "Withdraw";
            this.btnWithdraw.UseVisualStyleBackColor = true;
            this.btnWithdraw.Click += new System.EventHandler(this.btnWithdraw_Click);
            // 
            // btnDeposite
            // 
            this.btnDeposite.Location = new System.Drawing.Point(564, 137);
            this.btnDeposite.Name = "btnDeposite";
            this.btnDeposite.Size = new System.Drawing.Size(75, 23);
            this.btnDeposite.TabIndex = 4;
            this.btnDeposite.Text = "Deposite";
            this.btnDeposite.UseVisualStyleBackColor = true;
            this.btnDeposite.Click += new System.EventHandler(this.btnDeposite_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(346, 290);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 8;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(217, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(328, 31);
            this.label3.TabIndex = 9;
            this.label3.Text = "Maharashtra State Bank";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(317, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 31);
            this.label1.TabIndex = 10;
            this.label1.Text = "Welcome";
            // 
            // MainClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnBalance);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.btnWithdraw);
            this.Controls.Add(this.btnDeposite);
            this.Controls.Add(this.btnMinistatement);
            this.Controls.Add(this.btnLic);
            this.Controls.Add(this.btnBsnl);
            this.Controls.Add(this.btnMseb);
            this.Name = "MainClass";
            this.Text = "MainClass";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnMseb;
        private System.Windows.Forms.Button btnBsnl;
        private System.Windows.Forms.Button btnMinistatement;
        private System.Windows.Forms.Button btnLic;
        private System.Windows.Forms.Button btnBalance;
        private System.Windows.Forms.Button btnTransfer;
        private System.Windows.Forms.Button btnWithdraw;
        private System.Windows.Forms.Button btnDeposite;
        public System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
    }
}